import React from 'react';
import Feed from './components/Feed';
import './App.css';

function App() {
  return (
    <div className='main'>
      <Feed />
    </div>
  );
}

export default App;